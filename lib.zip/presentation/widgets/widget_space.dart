import 'package:flutter/material.dart';

Widget space({double? height,double? width}){
  return SizedBox(
    width: width,
    height: height,
  );
}