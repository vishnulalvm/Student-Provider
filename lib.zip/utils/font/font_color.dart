import 'package:flutter/material.dart';

class AppColor{
  static Color primaryColor = const Color.fromRGBO(199, 245, 245, 1);
  static Color fontColor = const Color.fromRGBO(29, 27, 32, 1);
}